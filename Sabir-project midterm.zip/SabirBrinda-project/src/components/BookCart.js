import React, { useContext } from "react";
import { Context } from "../context/Context";
import BookCartItem from "./BookCartItem";
import BookCartCheckOut from "./BookCartCheckOut";
import './BookCart.css'

const BookCart = () => {
  const { carts } = useContext(Context);

  if (carts.length === 0) {
    return (
      <h4 className="display-4 text-center my-5 addsome container">
        Add Some Products.
      </h4>
    );
  } else {
    return (
      <div className="text-center">
        <button className="display-8 bg-danger sc">shooping cart</button>
        <div className="container d-flex flex-column">
          {carts.map(cart => (
            <BookCartItem key={cart.id} cart={cart} />
          ))}
        </div>
        <BookCartCheckOut />
      </div>
    );
  }
};

export default BookCart;
