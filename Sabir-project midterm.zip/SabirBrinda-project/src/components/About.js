import React from "react";
import './About.css'


const About = () => {
  

  return (
    <div>
    <header>
  <section class="hero">
    <div class="left">
      <h1>Book Center <br/>from <br/><span>EveryWhere</span></h1>
      <p>Clicke button and find your Dream Book</p>
      <a href="/">Do it !</a>
    </div>
    <div class="right">
      <img src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1171&q=80" alt=""/>
    </div>
  </section>
</header>
</div>
  );
};

export default About;
