import React from "react";
import Search from "./Search";

const Header = () => {
  return (
    <div className="container search-header px-3 py-3 mx-auto text-center mt-sm-5">
    
      <p className="lead">find the book of your dreams</p>
      <Search />
    </div>
  );
};

export default Header;
